import os
import json
import re
import whisper
import shutil
import logging
import traceback
import numpy as np
from collections import Counter
from llama_cpp import Llama
from inputimeout import inputimeout, TimeoutOccurred
import sys
import time
import contextlib
import io
import torch

if getattr(sys, 'frozen', False):
    base_dir = os.path.dirname(sys.executable)
else:
    base_dir = os.path.dirname(os.path.abspath(__file__))

PROMPT_JSON_PATH = os.path.join(base_dir, "ustawienia.json")

DEFAULT_PROMPT = (
    "Na podstawie poniższej rozmowy z klientem:\n\n"
    "Podsumuj jego oczekiwania i czego dotyczyła rozmowa. Skoncentruj się na potrzebach, emocjach i intencjach rozmówcy. "
    "Napisz dokładnie trzy pełne zdania po polsku, tworząc jeden spójny akapit.\n\n"
    "Następnie, w nowej linii, podaj ocenę sentymentu w formacie:\n"
    "Sentyment: <opis>, Skala: <liczba od -1 do 1>\n\n"
    "Użyj dokładnie jednego z następujących opisów sentymentu: Bardzo negatywny, Negatywny, Neutralny, Pozytywny, Bardzo pozytywny.\n"
    "-1 oznacza bardzo negatywny ton, 0 to neutralny, a 1 to bardzo pozytywny. "
    "Używaj wartości pośrednich (np. -0.5, 0.3), jeśli ton wypowiedzi jest lekko negatywny lub umiarkowany.\n"
    "Unikaj ocen skrajnych (np. -1 lub 1), chyba że sytuacja tego wyraźnie wymaga (np. klient jest bardzo zdenerwowany lub bardzo zadowolony).\n\n"
    "---\n\n"
    "Przykład 1:\n"
    "Rozmowa:\n"
    "Klient zgłasza, że faktura zawiera drobną nieścisłość, ale nie jest zdenerwowany.\n"
    "Podsumowanie: Klient zauważył błąd na fakturze i chce, aby go poprawić. Nie wyraża złości ani frustracji, a rozmowa przebiega spokojnie.\n"
    "Sentyment: Neutralny, Skala: 0.0\n\n"
    "Przykład 2:\n"
    "Rozmowa:\n"
    "Klient mówi, że ma trudności z aplikacją mobilną, ale chwali obsługę techniczną za szybką pomoc.\n"
    "Podsumowanie: Klient miał problem z aplikacją, jednak docenił szybkie i profesjonalne wsparcie. Jest zadowolony z rozwiązania sytuacji.\n"
    "Sentyment: Pozytywny, Skala: 0.5\n\n"
    "Przykład 3:\n"
    "Rozmowa:\n"
    "Klient skarży się na długie oczekiwanie na połączenie z konsultantem, ale ostatecznie udało się załatwić sprawę.\n"
    "Podsumowanie: Klient był zirytowany czasem oczekiwania, ale sprawa została rozwiązana. Jego ton był umiarkowanie negatywny, lecz bez agresji.\n"
    "Sentyment: Negatywny, Skala: -0.5\n\n"
    "Przykład 4:\n"
    "Rozmowa:\n"
    "Klient chwali nową ofertę i mówi, że poleci operatora znajomym.\n"
    "Podsumowanie: Klient jest bardzo zadowolony z nowej oferty i deklaruje dalszą współpracę. Wyraża entuzjazm i pełne zadowolenie.\n"
    "Sentyment: Bardzo pozytywny, Skala: 1.0"
)

DEFAULT_KATEGORIE = {
    "reklamacja": ["reklamacja", "zwrot", "naprawa", "serwis", "gwarancja", "usterka", "problem", "uszkodzenie"],
    "sprzedaż": ["kupno", "zakup", "sprzedaż", "produkt", "cena", "zamówienie"],
    "lead": ["kupić", "zamówić", "potrzebuję", "internet", "telefon", "oferta"]
}

DEFAULT_TEMPERATURE = 0.4

AUDIO_EXTENSIONS = ('.mp3', '.wav', '.m4a')
WHISPER_MODEL_ORDER = ["large.pt", "medium.pt", "small.pt", "base.pt", "tiny.pt"]
BIELIK_MODEL_ORDER = [
    "Bielik-11B-v2.3-Instruct-EF16-OF16.Q8_0.gguf",
    "Bielik-11B-v2.3-Instruct.Q6_K.gguf",
    "Bielik-11B-v2.3-Instruct.Q4_K_M.gguf",
    "bielik-7b-instruct-v0.1.Q8_0.gguf",
    "bielik-7b-instruct-v0.1.Q6_K.gguf",
    "bielik-7b-instruct-v0.1.Q5_K_M.gguf",
    "bielik-7b-instruct-v0.1.Q4_K_M.gguf"
]
CATEGORY_FOLDER_MAP = {
    "reklamacja": "Reklamacje",
    "sprzedaż": "Sprzedaż",
    "lead": "Leads",
    "inne": "Inne"
}

bielik_dir = os.path.join(base_dir, "Bielik")
whisper_dir = os.path.join(base_dir, "Whisper")

os.environ["LLAMA_CPP_LOG_LEVEL"] = "ERROR"
sys.stderr = open(os.devnull, 'w')
logging.getLogger("llama_cpp").setLevel(logging.CRITICAL)

# Wykrywanie dostępności GPU i pytanie użytkownika
use_gpu_available = torch.cuda.is_available()
use_gpu = False

if use_gpu_available:
    print("🚀 Wykryto dostępny GPU:", torch.cuda.get_device_name(0))
    try:
        decision = input("❓ Czy chcesz użyć GPU? (t/n): ").strip().lower()
        if decision == "t":
            use_gpu = True
            print("✅ Wybrano tryb GPU.")
        else:
            print("👉 Wybrano tryb CPU.")
    except Exception:
        print("⚠️ Brak odpowiedzi – domyślnie używam CPU.")
else:
    print("💻 Nie wykryto GPU – działam w trybie CPU.")

USE_GPU_LAYERS = 20 if use_gpu else 0

def cut_to_3_sentences(text):
    # Prosty tokenizer oparty na kropkach, pytajnikach i wykrzyknikach
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    return ' '.join(sentences[:3])

def log_error_to_file(e):
    with open(os.path.join(base_dir, "error.log"), "a", encoding="utf-8") as log_file:
        log_file.write("\n=== BŁĄD ===\n")
        log_file.write(str(e) + "\n")
        log_file.write(traceback.format_exc())
        log_file.write("\n==============\n")

def log_debug(message):
    with open(os.path.join(base_dir, "debug.log"), "a", encoding="utf-8") as log_file:
        log_file.write(message + "\n")

def load_settings():
    default_settings = {
        "prompt": DEFAULT_PROMPT,
        "kategorie": DEFAULT_KATEGORIE,
        "temperature": DEFAULT_TEMPERATURE
    }

    if os.path.exists(PROMPT_JSON_PATH):
        with open(PROMPT_JSON_PATH, "r", encoding="utf-8") as f:
            settings = json.load(f)
        for key, value in default_settings.items():
            if key not in settings:
                settings[key] = value
    else:
        settings = default_settings

    with open(PROMPT_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2, ensure_ascii=False)

    return settings

settings = load_settings()

def summarize_and_analyze(text, llm):
    prompt = settings.get("prompt", DEFAULT_PROMPT)
    full_prompt = f"{prompt.strip()}\n\nRozmowa:\n{text.strip()}\n\n### Odpowiedź ###"

    print("\n⏳ Generowanie podsumowania i analizy sentymentu...")
    start_time = time.time()

    try:
        output = llm(full_prompt, max_tokens=256, temperature=settings.get("temperature", 0.4))
        response = output.get('choices', [{}])[0].get('text', '').strip()

        # Podziel wynik: podsumowanie + sentyment
        lines = response.splitlines()
        sentiment_line = next((l for l in lines if "Sentyment:" in l), "")
        summary = "\n".join(line for line in lines if "Sentyment:" not in line).strip()
        summary = re.sub(r"^\s*Podsumowanie:\s*", "", summary, flags=re.IGNORECASE)

        # Parsowanie sentymentu (obsługa Bardzo + Pozytywny/Negatywny/Neutralny)
        match = re.search(
            r"Sentyment:\s*(Bardzo\s+)?(Pozytywny|Negatywny|Neutralny|Positive|Negative|Neutral).*?Skala:\s*(-?\d+(\.\d+)?)",
            sentiment_line,
            re.IGNORECASE
        )
        if match:
            very_prefix = match.group(1) or ""  # np. "Bardzo "
            label_raw = match.group(2).lower()
            very = very_prefix.strip().lower() == "bardzo"
            if label_raw in ["pozytywny", "positive"]:
                sentiment_label = "Bardzo pozytywny" if very else "Pozytywny"
            elif label_raw in ["negatywny", "negative"]:
                sentiment_label = "Bardzo negatywny" if very else "Negatywny"
            elif label_raw in ["neutralny", "neutral"]:
                sentiment_label = "Neutralny"
            else:
                sentiment_label = "Neutralny"
            sentiment_score = round(float(match.group(3)), 2)
        else:
            sentiment_label = "Neutralny"
            sentiment_score = 0.0
            log_debug(f"⚠️ Nierozpoznany format sentymentu: '{sentiment_line}' – fallback na Neutralny")

        summary = cut_to_3_sentences(summary)
        if not summary:
            summary = "[Brak sensownego podsumowania]"

        end_time = time.time()
        print(f"✅ Gotowe w {round(end_time - start_time, 2)} sekundy. Sentyment: {sentiment_label} ({sentiment_score})")

        # Debug
        log_debug("🧪 [DEBUG] Prompt wysłany do Bielika:\n" + full_prompt[:1000] + "...\n")
        log_debug("🧪 [DEBUG] Odpowiedź modelu:\n" + response)
        log_debug(f"🧪 [DEBUG] Wynik sentymentu: {sentiment_label}, {sentiment_score}")

        return summary, sentiment_label, sentiment_score

    except Exception as e:
        log_debug(f"❌ Błąd w summarize_and_analyze:\n{str(e)}\n{traceback.format_exc()}")
        return "[Błąd generowania podsumowania]", "[Błąd analizy]", 0.0

def classify_topic(text):
    keywords = settings.get("kategorie", DEFAULT_KATEGORIE)
    text_lower = text.lower()
    for category, words in keywords.items():
        if any(word in text_lower for word in words):
            return category
    candidate_words = [w.lower() for w in re.findall(r'\b\w{4,}\b', text_lower)]
    most_common = Counter(candidate_words).most_common(5)
    suggested_keywords = [word for word, _ in most_common]
    suggested_name = suggested_keywords[0] if suggested_keywords else f"nowa_{len(keywords) + 1}"
    print(f"\n🆕 Wykryto nową kategorię!")
    print(f"🔍 Proponowana nazwa: {suggested_name}")
    print(f"🔑 Słowa kluczowe: {', '.join(suggested_keywords)}")
    custom_name = input("📝 Nazwa kategorii (Enter = sugerowana): ").strip()
    if not custom_name:
        custom_name = suggested_name
    keywords[custom_name] = suggested_keywords
    settings["kategorie"] = keywords
    with open(PROMPT_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2, ensure_ascii=False)
    return custom_name

def clean_transcription(text):
    fillers = ["yyy", "eee", "no więc", "tak", "prawda", "wie pani", "generalnie", "po prostu", "że tak powiem"]
    for filler in fillers:
        text = re.sub(rf'\b{filler}\b', '', text, flags=re.IGNORECASE)
    text = re.sub(r'\.\.+', '.', text)
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'(?<=\w)([.!?])(?=\w)', r'\1 ', text)
    text = text.strip()
    text = text[0].upper() + text[1:] if text else text
    return text

def save_report(folder, filename, category, transcription, cleaned, summary_pl, sentiment_label, sentiment_score):
    base_name = os.path.splitext(filename)[0]
    folder_name = CATEGORY_FOLDER_MAP.get(category, category.capitalize())
    report_folder = os.path.join(folder, folder_name)
    os.makedirs(report_folder, exist_ok=True)
    report_filename = f"{category}_{base_name}.txt"
    report_path = os.path.join(report_folder, report_filename)

    # Usuń ewentualny nagłówek "Podsumowanie:" z wygenerowanego podsumowania
    if summary_pl:
        summary_pl = re.sub(r"^\s*Podsumowanie:\s*", "", summary_pl.strip(), flags=re.IGNORECASE)

    try:
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(f"=== RAPORT ANALIZY AUDIO: {filename} ===\n\n")
            f.write("📌 Transkrypcja:\n" + (transcription or "[Brak transkrypcji]") + "\n\n")
            f.write("📋 Podsumowanie:\n" + (summary_pl or "[Brak podsumowania]") + "\n\n")
            f.write(f"🔍 Sentyment: {sentiment_label or '[Brak]'} ({sentiment_score if sentiment_score is not None else '---'})\n")
            f.write(f"🗂️ Kategoria: {category}\n")
        print(f"\n✅ Raport {report_filename} został zapisany w folderze {report_folder}")
    except Exception as e:
        print(f"❌ Błąd podczas zapisu raportu: {e}")
        log_error_to_file(e)

def find_best_local_model(search_dirs, model_order, model_type=None):
    for model_name in model_order:
        for d in search_dirs:
            full_path = os.path.join(d, model_name)
            if os.path.isfile(full_path):
                if model_type:
                    print(f"✅ Znaleziono lokalny model {model_type}: {full_path}")
                return full_path
    for d in search_dirs:
        if os.path.isdir(d):
            for f in os.listdir(d):
                if f.endswith(".gguf") or f.endswith(".pt"):
                    path = os.path.join(d, f)
                    if model_type:
                        print(f"✅ Znaleziono lokalny model {model_type}: {path}")
                    return path
    return None

import urllib.request

import whisper
import shutil
import time
import os
from pathlib import Path

def pobierz_bielika():
    import urllib.request

    print("🔍 Szukam lokalnego modelu Bielik...")

    model_path = find_best_local_model([bielik_dir], BIELIK_MODEL_ORDER, model_type="Bielik")
    if model_path:
        return model_path

    # Definicje wariantów z szacowanymi rozmiarami (MB)
    bielik_warianty = [
        {"key": "bielik-7b-q4", "plik": "bielik-7b-instruct-v0.1.Q4_K_M.gguf", "url": "https://huggingface.co/speakleash/bielik-7b-instruct-v0.1-GGUF/resolve/main/bielik-7b-instruct-v0.1.Q4_K_M.gguf", "size_mb": 1800},
        {"key": "bielik-7b-q6", "plik": "bielik-7b-instruct-v0.1.Q6_K.gguf", "url": "https://huggingface.co/speakleash/bielik-7b-instruct-v0.1-GGUF/resolve/main/bielik-7b-instruct-v0.1.Q6_K.gguf", "size_mb": 2100},
        {"key": "bielik-7b-q8", "plik": "bielik-7b-instruct-v0.1.Q8_0.gguf", "url": "https://huggingface.co/speakleash/bielik-7b-instruct-v0.1-GGUF/resolve/main/bielik-7b-instruct-v0.1.Q8_0.gguf", "size_mb": 3000},
        {"key": "bielik-11b-q4", "plik": "Bielik-11B-v2.3-Instruct.Q4_K_M.gguf", "url": "https://huggingface.co/speakleash/Bielik-11B-v2.3-Instruct-GGUF/resolve/main/Bielik-11B-v2.3-Instruct.Q4_K_M.gguf", "size_mb": 4800},
        {"key": "bielik-11b-q6", "plik": "Bielik-11B-v2.3-Instruct.Q6_K.gguf", "url": "https://huggingface.co/speakleash/Bielik-11B-v2.3-Instruct-GGUF/resolve/main/Bielik-11B-v2.3-Instruct.Q6_K.gguf", "size_mb": 6000},
        {"key": "bielik-11b-q8", "plik": "Bielik-11B-v2.3-Instruct.Q8_0.gguf", "url": "https://huggingface.co/speakleash/Bielik-11B-v2.3-Instruct-GGUF/resolve/main/Bielik-11B-v2.3-Instruct.Q8_0.gguf", "size_mb": 8500},
        {"key": "bielik-11b-q8-of16", "plik": "Bielik-11B-v2.3-Instruct-EF16-OF16.Q8_0.gguf", "url": "https://huggingface.co/speakleash/Bielik-11B-v2.3-Instruct-GGUF/resolve/main/Bielik-11B-v2.3-Instruct-EF16-OF16.Q8_0.gguf", "size_mb": 8700}
    ]

    # Wczytaj ustawienia
    with open(PROMPT_JSON_PATH, "r", encoding="utf-8") as f:
        settings = json.load(f)

    default_model = settings.get("default_bielik", "bielik-7b-q6")

    # Detekcja dostępnego VRAM
    try:
        if torch.cuda.is_available():
            total_vram = torch.cuda.get_device_properties(0).total_memory // (1024 * 1024)
            print(f"\n💻 Dostępna pamięć GPU: {total_vram} MB")
        else:
            total_vram = 0
            print("\n💻 Nie wykryto GPU — tryb CPU.")
    except Exception:
        total_vram = 0
        print("\n💻 Nie udało się wykryć VRAM — przyjmuję 0 MB.")

    # Sugerowany model na podstawie VRAM
    rekomendowany = next((w for w in reversed(bielik_warianty) if w["size_mb"] < total_vram * 0.9), bielik_warianty[0])
    print(f"🔎 Rekomendowany model: {rekomendowany['key']} (~{rekomendowany['size_mb']} MB)")

    # Wyświetl wszystkie warianty
    print("\n📦 Dostępne warianty:")
    for i, w in enumerate(bielik_warianty, 1):
        ozn = "✅" if w["key"] == rekomendowany["key"] else "  "
        print(f" {i}. {w['key'].ljust(22)} ({w['size_mb']} MB) {ozn}")

    wybor = input(f"\n📝 Wybierz numer modelu do pobrania (Enter = {default_model}): ").strip()

    if not wybor:
        wybor_key = default_model
    elif wybor.isdigit() and 1 <= int(wybor) <= len(bielik_warianty):
        wybor_key = bielik_warianty[int(wybor) - 1]["key"]
    else:
        print("⚠️ Nieprawidłowy wybór – używam domyślnego wariantu.")
        wybor_key = default_model

    # Zapisz nowy domyślny wariant
    settings["default_bielik"] = wybor_key
    with open(PROMPT_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2, ensure_ascii=False)

    info = next(w for w in bielik_warianty if w["key"] == wybor_key)
    plik_nazwa = info["plik"]
    url = info["url"]

    os.makedirs(bielik_dir, exist_ok=True)
    save_path = os.path.join(bielik_dir, plik_nazwa)

    print(f"\n📡 Pobieranie modelu {wybor_key}...")
    print(f"🌐 URL: {url}")
    print(f"💾 Zapis do: {save_path}")

    try:
        urllib.request.urlretrieve(url, save_path)
        print(f"✅ Model zapisany jako: {save_path}")

        if plik_nazwa not in BIELIK_MODEL_ORDER:
            BIELIK_MODEL_ORDER.insert(0, plik_nazwa)

        return save_path

    except Exception as e:
        print(f"❌ Błąd podczas pobierania modelu Bielik: {e}")
        raise RuntimeError("Nie udało się pobrać modelu Bielik.")

def transcribe_audio(audio_path, language="pl"):
    print(f"\n⏳ Transkrypcja pliku: {audio_path}")
    search_dirs = [whisper_dir]
    local_model_path = find_best_local_model(search_dirs, WHISPER_MODEL_ORDER)

    try:
        if local_model_path:
            print(f"✅ Znaleziono lokalny model Whisper do transkrypcji: {local_model_path}")
            model = whisper.load_model(local_model_path)

        else:
            print("⚠️ Nie znaleziono lokalnego modelu Whisper (.pt).")

            # 📦 Lista modeli z szacowanymi rozmiarami
            whisper_variants = [
                {"name": "tiny", "size_mb": 75},
                {"name": "base", "size_mb": 142},
                {"name": "small", "size_mb": 466},
                {"name": "medium", "size_mb": 1460},
                {"name": "large", "size_mb": 2900}
            ]

            # Wykryj VRAM
            try:
                if torch.cuda.is_available():
                    total_vram = torch.cuda.get_device_properties(0).total_memory // (1024 * 1024)
                    print(f"\n💻 Dostępna pamięć GPU: {total_vram} MB")
                else:
                    total_vram = 0
                    print("\n💻 Nie wykryto GPU — tryb CPU.")
            except:
                total_vram = 0
                print("\n💻 Nie udało się wykryć VRAM — przyjmuję 0 MB.")

            # Sugerowany model Whisper
            rekomendowany = next((w for w in reversed(whisper_variants) if w["size_mb"] < total_vram * 0.8), whisper_variants[0])
            print(f"🔎 Rekomendowany model Whisper: {rekomendowany['name']} (~{rekomendowany['size_mb']} MB)")

            print("\n📦 Dostępne modele Whisper:")
            for i, w in enumerate(whisper_variants, 1):
                ozn = "✅" if w["name"] == rekomendowany["name"] else "  "
                print(f" {i}. {w['name'].ljust(8)} ({w['size_mb']} MB) {ozn}")

            user_choice = input(f"\n📝 Wybierz numer modelu Whisper (Enter = {rekomendowany['name']}): ").strip()

            if not user_choice:
                user_model = rekomendowany["name"]
            elif user_choice.isdigit() and 1 <= int(user_choice) <= len(whisper_variants):
                user_model = whisper_variants[int(user_choice) - 1]["name"]
            else:
                print("⚠️ Nieprawidłowy wybór. Używam domyślnego wariantu.")
                user_model = rekomendowany["name"]

            print(f"\n📡 Pobieranie modelu '{user_model}' przez whisper.load_model('{user_model}')...")
            model = whisper.load_model(user_model)
            print(f"✅ Model '{user_model}' został pobrany i załadowany.")

            # Ścieżka do cache i miejsce docelowe
            cache_path = Path.home() / ".cache" / "whisper" / f"{user_model}.pt"
            dest_path = os.path.join(whisper_dir, f"{user_model}.pt")
            os.makedirs(whisper_dir, exist_ok=True)

            try:
                shutil.copy2(cache_path, dest_path)
                print(f"💾 Skopiowano model z cache do: {dest_path}")

                # Usuń z cache
                if os.path.isfile(cache_path):
                    os.remove(cache_path)
                    print(f"🧹 Usunięto model z cache: {cache_path}")

                # Dodaj do listy znanych modeli
                if f"{user_model}.pt" not in WHISPER_MODEL_ORDER:
                    WHISPER_MODEL_ORDER.insert(0, f"{user_model}.pt")

            except Exception as copy_err:
                print(f"⚠️ Nie udało się skopiować modelu do folderu Whisper lub usunąć cache: {copy_err}")

    except Exception as ex:
        print(f"❌ Błąd przy ładowaniu modelu Whisper: {ex}")
        raise RuntimeError("Nie udało się załadować modelu Whisper.")

    start_time = time.time()
    fp16 = use_gpu and torch.cuda.get_device_capability(0)[0] >= 7
    result = model.transcribe(audio_path, language=language, fp16=use_gpu)
    end_time = time.time()

    elapsed = round(end_time - start_time, 2)
    print(f"✅ Transkrypcja zakończona w {elapsed} sekundy.")

    transcription = result['text']
    print("\n🎵 Transkrypcja:\n", transcription)
    return transcription

def show_gpu_info():
    print("\n💻 Wykrywanie trybu działania modeli...")
    whisper_mode = "GPU" if use_gpu else "CPU"
    try:
        if torch.cuda.is_available():
            gpu_name = torch.cuda.get_device_name(0)
            bielik_mode = "GPU"
        else:
            gpu_name = "Brak CUDA (CPU)"
            bielik_mode = "CPU"
    except:
        gpu_name = "Brak dostępnego GPU CUDA"
        bielik_mode = "CPU"

    print(f"🔍 GPU: {gpu_name}")
    print(f"🎵 Whisper: {whisper_mode} | 🦅 Bielik: {bielik_mode}\n")

def main():
    print("🚀 START MAIN")
    show_gpu_info()
    folder = base_dir
    user_input = input("📂 Folder z nagraniami (Enter = domyślny): ").strip()
    if user_input:
        folder = user_input
    if not os.path.isdir(folder):
        print(f"❌ Folder '{folder}' nie istnieje.")
        input("\n❌ Enter, by zakończyć...")
        return

    files = [f for f in os.listdir(folder) if f.lower().endswith(AUDIO_EXTENSIONS)]
    if not files:
        print(f"❌ W folderze '{folder}' nie ma nagrań.")
        input("\n🔺 Enter, by zakończyć...")
        return

    try:
        model_path = pobierz_bielika()
    except Exception as e:
        print(f"❌ Błąd: {e}")
        input("\n🔺 Naciśnij Enter, aby zakończyć...")
        return

    try:
        llm = Llama(
            model_path=model_path,
            n_ctx=2056,
            n_gpu_layers=USE_GPU_LAYERS,
            n_threads=os.cpu_count(),
            embedding=False,
            chat_format=None
        )
    except OSError as e:
        print(f"⚠️ Nie udało się uruchomić Llama z GPU. Próbuję w trybie CPU...\nBłąd: {e}")
        try:
            llm = Llama(
                model_path=model_path,
                n_ctx=2056,
                n_gpu_layers=0,
                n_threads=os.cpu_count(),
                embedding=False,
                chat_format=None
            )
        except Exception as ex:
            print(f"❌ Błąd krytyczny: {ex}")
            log_error_to_file(ex)
            input("\n🚩 Naciśnij Enter, aby zamknąć...")
            return

    for audio_file in files:
        print(f"\n🔎 Znaleziono: {audio_file}")
        try:
            response = inputimeout(prompt="Czy chcesz przeanalizować? (t/n): ", timeout=3).strip().lower()
        except TimeoutOccurred:
            print("⏳ Brak odpowiedzi – analizuję domyślnie...")
            response = 't'

        if response == 't':
            try:
                full_path = os.path.join(folder, audio_file)
                transcription = transcribe_audio(full_path)
                cleaned = clean_transcription(transcription)

                print(f"\n✅ Znaleziono lokalny model Bielik do podsumowania i sentymentu: {model_path}")

                summary_pl, sentiment_label, sentiment_score = summarize_and_analyze(cleaned, llm)
                category = classify_topic(cleaned)

                print("\n📋 Podsumowanie:\n" + (summary_pl or "[Brak podsumowania]"))
                print(f"\n🗂️ Kategoria: {category.capitalize()}")

                save_report(folder, audio_file, category, transcription, cleaned, summary_pl, sentiment_label, sentiment_score)
            except Exception as e:
                print(f"❌ Błąd: {e}")
                log_error_to_file(e)
        else:
            print("⏭️ Pominięto plik.")

    input("\n🔚 Naciśnij Enter, aby zakończyć...")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n❌ Błąd krytyczny: {e}")
        log_error_to_file(e)
        input("\n🚩 Naciśnij Enter, aby zamknąć...")
